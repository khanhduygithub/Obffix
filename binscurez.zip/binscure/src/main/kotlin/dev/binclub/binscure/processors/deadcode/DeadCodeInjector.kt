package dev.binclub.binscure.processors.deadcode

import dev.binclub.binscure.CObfuscator
import dev.binclub.binscure.IClassProcessor
import dev.binclub.binscure.api.TransformerConfiguration
import dev.binclub.binscure.classpath.ClassSources
import dev.binclub.binscure.configuration.ConfigurationManager.rootConfig
import dev.binclub.binscure.utils.*
import org.objectweb.asm.Opcodes.*
import org.objectweb.asm.tree.*

/**
 * Dead Code Injector: inserts unreachable but realistic-looking bytecode blocks
 * after GOTO/RETURN instructions to confuse decompilers and reverse engineers.
 */
class DeadCodeInjector(source: ClassSources) : IClassProcessor(source) {

    override val progressDescription = "Injecting dead code blocks"
    override val config = object : TransformerConfiguration(true, emptyList()) {
        override val enabled = rootConfig.deadCode.enabled
    }

    // Probability weight: 1 in N methods get dead code
    private val density get() = rootConfig.deadCode.density.coerceIn(1, 20)

    override fun process(
        source: ClassSources,
        classes: MutableCollection<ClassNode>,
        passThrough: MutableMap<String, ByteArray>
    ) {
        if (!rootConfig.deadCode.enabled) return

        for (classNode in classes) {
            if (isExcluded(classNode)) continue
            if (classNode.access and ACC_INTERFACE != 0) continue

            for (method in classNode.methods) {
                if (CObfuscator.noMethodInsns(method)) continue
                if (isExcluded(classNode, method)) continue
                if (method.instructions.size() < 4) continue

                injectDeadCode(method)
            }
        }
    }

    private fun injectDeadCode(method: MethodNode) {
        val modifier = InstructionModifier()
        val insns = method.instructions.toArray()

        for (insn in insns) {
            // Only inject after GOTO or xRETURN instructions
            val isReturn = insn.opcode in listOf(RETURN, ARETURN, IRETURN, LRETURN, FRETURN, DRETURN)
            val isGoto = insn.opcode == GOTO

            if ((isReturn || isGoto) && random.nextInt(density) == 0) {
                val deadBlock = generateDeadBlock(method)
                modifier.append(insn, deadBlock)
            }
        }
        modifier.apply(method)
    }

    private fun generateDeadBlock(method: MethodNode): InsnList {
        return InsnList().apply {
            val skipLabel = LabelNode()
            // Unconditional GOTO over dead block - this block is truly unreachable
            add(JumpInsnNode(GOTO, skipLabel))

            // Dead block content - looks real, never executes
            when (random.nextInt(6)) {
                0 -> {
                    // Fake string decryption
                    add(LdcInsnNode(generateGarbageString()))
                    add(MethodInsnNode(INVOKEVIRTUAL, "java/lang/String", "length", "()I", false))
                    add(InsnNode(POP))
                }
                1 -> {
                    // Fake arithmetic
                    add(ldcInt(random.nextInt()))
                    add(ldcInt(random.nextInt()))
                    add(InsnNode(IMUL))
                    add(ldcInt(random.nextInt()))
                    add(InsnNode(IXOR))
                    add(InsnNode(POP))
                }
                2 -> {
                    // Fake exception throw
                    add(TypeInsnNode(NEW, "java/lang/RuntimeException"))
                    add(InsnNode(DUP))
                    add(LdcInsnNode("error"))
                    add(MethodInsnNode(INVOKESPECIAL, "java/lang/RuntimeException", "<init>", "(Ljava/lang/String;)V", false))
                    add(InsnNode(ATHROW))
                }
                3 -> {
                    // Fake System.exit
                    add(ldcInt(random.nextInt(256)))
                    add(MethodInsnNode(INVOKESTATIC, "java/lang/System", "exit", "(I)V", false))
                }
                4 -> {
                    // Fake array operations
                    add(ldcInt(random.nextInt(100) + 1))
                    add(IntInsnNode(NEWARRAY, T_INT))
                    add(InsnNode(POP))
                }
                5 -> {
                    // Fake instanceof + cast
                    add(InsnNode(ACONST_NULL))
                    add(TypeInsnNode(INSTANCEOF, "java/lang/String"))
                    add(InsnNode(POP))
                }
            }

            add(skipLabel)
        }
    }

    private fun generateGarbageString(): String {
        val len = random.nextInt(12) + 4
        return (0 until len).map { ('a' + random.nextInt(26)).toChar() }.joinToString("")
    }
}
