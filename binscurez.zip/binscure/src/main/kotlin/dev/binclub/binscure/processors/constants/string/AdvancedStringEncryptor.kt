package dev.binclub.binscure.processors.constants.string

import dev.binclub.binscure.CObfuscator
import dev.binclub.binscure.IClassProcessor
import dev.binclub.binscure.api.transformers.StringObfuscationConfiguration
import dev.binclub.binscure.classpath.ClassSources
import dev.binclub.binscure.configuration.ConfigurationManager.rootConfig
import dev.binclub.binscure.utils.*
import org.objectweb.asm.ClassWriter
import org.objectweb.asm.Opcodes.*
import org.objectweb.asm.tree.*
import java.security.MessageDigest
import java.util.*

/**
 * Advanced String Encryptor - Multi-algorithm, dynamic keys, anti-dump, dead methods
 */
class AdvancedStringEncryptor(source: ClassSources) : IClassProcessor(source) {

    override val progressDescription = "Advanced string encryption (multi-algo + anti-dump)"
    override val config: StringObfuscationConfiguration = rootConfig.stringObfuscation

    // 7 algorithm selectors - each string uses a different algo based on index % 7
    private val masterSeed = random.nextLong()

    // Per-run random keys for each algorithm slot
    private val algoKeys = Array(7) {
        val k = IntArray(8) { random.nextInt() }
        k
    }

    data class EncEntry(
        val original: String,
        val encrypted: String,
        val algoIndex: Int,
        val classNode: ClassNode,
        val methodNode: MethodNode,
        val insn: LdcInsnNode,
        val stringIndex: Int
    )

    override fun process(
        source: ClassSources,
        classes: MutableCollection<ClassNode>,
        passThrough: MutableMap<String, ByteArray>
    ) {
        if (!config.enabled) return

        val entries = mutableListOf<EncEntry>()
        var globalIdx = 0

        for (classNode in classes) {
            if (isExcluded(classNode)) continue
            for (method in classNode.methods) {
                if (isExcluded(classNode, method) || CObfuscator.noMethodInsns(method)) continue
                for (insn in method.instructions) {
                    if (insn is LdcInsnNode && insn.cst is String) {
                        val s = insn.cst as String
                        if (s.length < 2 || s.length > config.maxLength) continue
                        val algoIdx = globalIdx % 7
                        val enc = encryptWithAlgo(s, algoIdx, classNode, method, globalIdx)
                        entries.add(EncEntry(s, enc, algoIdx, classNode, method, insn, globalIdx))
                        globalIdx++
                    }
                }
            }
        }

        if (entries.isEmpty()) return

        // Generate the runtime decryptor class
        val decryptClassName = CObfuscator.classNamer.uniqueUntakenClass(source)
        val decryptClass = buildDecryptorClass(decryptClassName, source)

        // Generate the main dispatch decrypt method
        val dispatchMethod = buildDispatchMethod(decryptClass)

        // Generate 7 algorithm methods (real)
        val algoMethods = (0..6).map { buildAlgoMethod(it, decryptClass) }

        // Generate ~15 fake dead methods to confuse decompilers
        repeat(15) { buildFakeMethod(decryptClass, it) }

        // Generate anti-dump check method
        val antiDumpMethod = buildAntiDumpMethod(decryptClass)

        // Generate static initializer for keys
        buildStaticInit(decryptClass)

        // Write decryptor class to passthrough
        val cw = ClassWriter(ClassWriter.COMPUTE_FRAMES)
        decryptClass.accept(cw)
        passThrough["$decryptClassName.class"] = cw.toByteArray()
        // Class written to passThrough only - no need to add to classPath

        // Replace each LDC instruction with encrypted + call to dispatcher
        for (entry in entries) {
            entry.insn.cst = entry.encrypted
            val modifier = InstructionModifier()
            val list = InsnList().apply {
                add(ldcInt(entry.algoIndex))
                add(ldcInt(entry.classNode.name.hashCode()))
                add(ldcInt(entry.methodNode.name.hashCode()))
                add(ldcInt(entry.stringIndex))
                add(MethodInsnNode(
                    INVOKESTATIC,
                    decryptClassName,
                    dispatchMethod.name,
                    dispatchMethod.desc,
                    false
                ))
            }
            modifier.append(entry.insn, list)
            modifier.apply(entry.methodNode)
        }
    }

    // ---- Encryption (compile-time, runs in obfuscator) ----

    private fun encryptWithAlgo(text: String, algo: Int, cn: ClassNode, mn: MethodNode, idx: Int): String {
        val classHash = cn.name.hashCode()
        val methodHash = mn.name.hashCode()
        val key = algoKeys[algo]
        val chars = text.toCharArray()
        return when (algo % 7) {
            0 -> encAlgo0(chars, key, classHash, methodHash, idx)
            1 -> encAlgo1(chars, key, classHash, methodHash, idx)
            2 -> encAlgo2(chars, key, classHash, methodHash, idx)
            3 -> encAlgo3(chars, key, classHash, methodHash, idx)
            4 -> encAlgo4(chars, key, classHash, methodHash, idx)
            5 -> encAlgo5(chars, key, classHash, methodHash, idx)
            6 -> encAlgo6(chars, key, classHash, methodHash, idx)
            else -> text
        }
    }

    // Algorithm 0: XOR with class+method hash chain
    private fun encAlgo0(chars: CharArray, key: IntArray, ch: Int, mh: Int, idx: Int): String {
        val out = CharArray(chars.size)
        for (i in chars.indices) {
            out[i] = (chars[i].code xor (key[i % 8]) xor (ch shl (i % 7)) xor (mh ushr (i % 5))).toChar()
        }
        return String(out)
    }

    // Algorithm 1: Reverse + XOR
    private fun encAlgo1(chars: CharArray, key: IntArray, ch: Int, mh: Int, idx: Int): String {
        val rev = chars.reversedArray()
        val out = CharArray(rev.size)
        for (i in rev.indices) {
            out[i] = (rev[i].code xor key[i % 8] xor mh).toChar()
        }
        return String(out)
    }

    // Algorithm 2: Double XOR layers
    private fun encAlgo2(chars: CharArray, key: IntArray, ch: Int, mh: Int, idx: Int): String {
        val out = CharArray(chars.size)
        for (i in chars.indices) {
            val layer1 = chars[i].code xor key[i % 8]
            val layer2 = layer1 xor (ch + mh + i)
            out[i] = (layer2 and 0xFFFF).toChar()
        }
        return String(out)
    }

    // Algorithm 3: Rotate bits + XOR
    private fun encAlgo3(chars: CharArray, key: IntArray, ch: Int, mh: Int, idx: Int): String {
        val out = CharArray(chars.size)
        for (i in chars.indices) {
            val rotated = Integer.rotateLeft(chars[i].code, (i + 3) % 16)
            out[i] = ((rotated xor key[i % 8] xor idx) and 0xFFFF).toChar()
        }
        return String(out)
    }

    // Algorithm 4: Fibonacci-seeded XOR
    private fun encAlgo4(chars: CharArray, key: IntArray, ch: Int, mh: Int, idx: Int): String {
        val out = CharArray(chars.size)
        var fib1 = key[0]; var fib2 = key[1]
        for (i in chars.indices) {
            val fibN = fib1 + fib2
            fib1 = fib2; fib2 = fibN
            out[i] = (chars[i].code xor (fibN and 0xFFFF) xor ch).toChar()
        }
        return String(out)
    }

    // Algorithm 5: Interleave noise + XOR
    private fun encAlgo5(chars: CharArray, key: IntArray, ch: Int, mh: Int, idx: Int): String {
        val out = CharArray(chars.size)
        for (i in chars.indices) {
            val noise = (i * 31 + mh) and 0xFFFF
            out[i] = (chars[i].code xor key[i % 8] xor noise).toChar()
        }
        return String(out)
    }

    // Algorithm 6: SHA-based key derivation per char
    private fun encAlgo6(chars: CharArray, key: IntArray, ch: Int, mh: Int, idx: Int): String {
        val out = CharArray(chars.size)
        val seed = (ch.toLong() * 1000003L + mh.toLong() + idx.toLong())
        for (i in chars.indices) {
            val k = ((seed + i) xor key[i % 8].toLong()).toInt()
            out[i] = (chars[i].code xor k).toChar()
        }
        return String(out)
    }

    // ---- Bytecode generation for decryptor class ----

    private fun buildDecryptorClass(name: String, source: ClassSources): ClassNode {
        return ClassNode().apply {
            access = ACC_PUBLIC or ACC_FINAL
            version = V11
            this.name = name
            superName = "java/lang/Object"
            signature = null
            sourceFile = null
            sourceDebug = null

            // Static key arrays field - one int[] per algo
            fields.add(FieldNode(ACC_PRIVATE or ACC_STATIC or ACC_FINAL, "K", "[[I", null, null))
        }
    }

    private fun buildStaticInit(cn: ClassNode) {
        val mn = MethodNode(ACC_STATIC, "<clinit>", "()V", null, null)
        val il = mn.instructions
        // Allocate K = new int[7][]
        il.add(ldcInt(7))
        il.add(TypeInsnNode(ANEWARRAY, "[I"))

        for (algo in 0..6) {
            val k = algoKeys[algo]
            il.add(DUP)
            il.add(ldcInt(algo))
            il.add(ldcInt(8))
            il.add(IntInsnNode(NEWARRAY, T_INT))
            for (j in 0..7) {
                il.add(DUP)
                il.add(ldcInt(j))
                il.add(ldcInt(k[j]))
                il.add(InsnNode(IASTORE))
            }
            il.add(InsnNode(AASTORE))
        }
        il.add(FieldInsnNode(PUTSTATIC, cn.name, "K", "[[I"))
        il.add(InsnNode(RETURN))
        cn.methods.add(mn)
    }

    /**
     * Dispatch method:
     * String decrypt(String enc, int algo, int classHash, int methodHash, int strIdx)
     */
    private fun buildDispatchMethod(cn: ClassNode): MethodNode {
        val mn = MethodNode(
            ACC_PUBLIC or ACC_STATIC,
            "d",
            "(Ljava/lang/String;IIIILjava/lang/Object;)Ljava/lang/String;",
            null, null
        )
        val il = mn.instructions
        val labels = Array(7) { LabelNode() }
        val defaultLabel = LabelNode()
        val endLabel = LabelNode()

        // Anti-dump check first
        il.add(MethodInsnNode(INVOKESTATIC, cn.name, "z", "()Z", false))
        val skipFake = LabelNode()
        il.add(JumpInsnNode(IFEQ, skipFake))
        // Return fake value if under agent/debug
        il.add(LdcInsnNode("\u0000"))
        il.add(InsnNode(ARETURN))
        il.add(skipFake)

        // switch(algo % 7)
        il.add(VarInsnNode(ILOAD, 1))
        il.add(ldcInt(7))
        il.add(InsnNode(IREM))
        il.add(TableSwitchInsnNode(0, 6, defaultLabel, *labels))

        for (i in 0..6) {
            il.add(labels[i])
            il.add(VarInsnNode(ALOAD, 0))
            il.add(ldcInt(i))
            il.add(VarInsnNode(ILOAD, 2))
            il.add(VarInsnNode(ILOAD, 3))
            il.add(VarInsnNode(ILOAD, 4))
            il.add(MethodInsnNode(INVOKESTATIC, cn.name, "a$i", "(Ljava/lang/String;IIII)Ljava/lang/String;", false))
            il.add(JumpInsnNode(GOTO, endLabel))
        }

        il.add(defaultLabel)
        il.add(VarInsnNode(ALOAD, 0))

        il.add(endLabel)
        il.add(InsnNode(ARETURN))
        cn.methods.add(mn)
        return mn
    }

    // Simplified dispatch for call site: (String, int, int, int, int) -> String
    private fun buildSimpleDispatch(cn: ClassNode): MethodNode {
        val mn = MethodNode(
            ACC_PUBLIC or ACC_STATIC,
            "dc",
            "(Ljava/lang/String;IIII)Ljava/lang/String;",
            null, null
        )
        val il = mn.instructions
        il.add(VarInsnNode(ALOAD, 0))
        il.add(VarInsnNode(ILOAD, 1))
        il.add(VarInsnNode(ILOAD, 2))
        il.add(VarInsnNode(ILOAD, 3))
        il.add(VarInsnNode(ILOAD, 4))
        il.add(InsnNode(ACONST_NULL))
        il.add(MethodInsnNode(INVOKESTATIC, cn.name, "d", "(Ljava/lang/String;IIIILjava/lang/Object;)Ljava/lang/String;", false))
        il.add(InsnNode(ARETURN))
        cn.methods.add(mn)
        return mn
    }

    private fun buildAlgoMethod(algo: Int, cn: ClassNode): MethodNode {
        val mn = MethodNode(
            ACC_PRIVATE or ACC_STATIC,
            "a$algo",
            "(Ljava/lang/String;IIII)Ljava/lang/String;",
            null, null
        )
        val il = mn.instructions
        // char[] chars = enc.toCharArray()
        il.add(VarInsnNode(ALOAD, 0))
        il.add(MethodInsnNode(INVOKEVIRTUAL, "java/lang/String", "toCharArray", "()[C", false))
        il.add(VarInsnNode(ASTORE, 5)) // chars

        // int[] key = K[algo]
        il.add(FieldInsnNode(GETSTATIC, cn.name, "K", "[[I"))
        il.add(ldcInt(algo))
        il.add(InsnNode(AALOAD))
        il.add(VarInsnNode(ASTORE, 6)) // key

        // char[] out = new char[chars.length]
        il.add(VarInsnNode(ALOAD, 5))
        il.add(InsnNode(ARRAYLENGTH))
        il.add(IntInsnNode(NEWARRAY, T_CHAR))
        il.add(VarInsnNode(ASTORE, 7)) // out

        // int i = 0
        il.add(ldcInt(0))
        il.add(VarInsnNode(ISTORE, 8))

        val loopStart = LabelNode()
        val loopEnd = LabelNode()
        il.add(loopStart)
        // if (i >= chars.length) break
        il.add(VarInsnNode(ILOAD, 8))
        il.add(VarInsnNode(ALOAD, 5))
        il.add(InsnNode(ARRAYLENGTH))
        il.add(JumpInsnNode(IF_ICMPGE, loopEnd))

        // Each algorithm decryption logic (inverse of encrypt)
        when (algo) {
            0 -> {
                // out[i] = (chars[i] ^ key[i%8] ^ (classHash << (i%7)) ^ (methodHash >>> (i%5)))
                il.add(VarInsnNode(ALOAD, 7))
                il.add(VarInsnNode(ILOAD, 8))
                il.add(VarInsnNode(ALOAD, 5))
                il.add(VarInsnNode(ILOAD, 8))
                il.add(InsnNode(CALOAD))
                il.add(VarInsnNode(ALOAD, 6))
                il.add(VarInsnNode(ILOAD, 8))
                il.add(ldcInt(8))
                il.add(InsnNode(IREM))
                il.add(InsnNode(IALOAD))
                il.add(InsnNode(IXOR))
                il.add(VarInsnNode(ILOAD, 2)) // classHash
                il.add(VarInsnNode(ILOAD, 8))
                il.add(ldcInt(7))
                il.add(InsnNode(IREM))
                il.add(InsnNode(ISHL))
                il.add(InsnNode(IXOR))
                il.add(VarInsnNode(ILOAD, 3)) // methodHash
                il.add(VarInsnNode(ILOAD, 8))
                il.add(ldcInt(5))
                il.add(InsnNode(IREM))
                il.add(InsnNode(IUSHR))
                il.add(InsnNode(IXOR))
                il.add(ldcInt(0xFFFF))
                il.add(InsnNode(IAND))
                il.add(InsnNode(I2C))
                il.add(InsnNode(CASTORE))
            }
            1 -> {
                // Reverse was applied, so we reverse output
                il.add(VarInsnNode(ALOAD, 7))
                il.add(VarInsnNode(ILOAD, 8))
                // out[i] = (chars[n-1-i] ^ key[i%8] ^ methodHash)
                il.add(VarInsnNode(ALOAD, 5))
                il.add(VarInsnNode(ALOAD, 5))
                il.add(InsnNode(ARRAYLENGTH))
                il.add(ldcInt(1))
                il.add(InsnNode(ISUB))
                il.add(VarInsnNode(ILOAD, 8))
                il.add(InsnNode(ISUB))
                il.add(InsnNode(CALOAD))
                il.add(VarInsnNode(ALOAD, 6))
                il.add(VarInsnNode(ILOAD, 8))
                il.add(ldcInt(8))
                il.add(InsnNode(IREM))
                il.add(InsnNode(IALOAD))
                il.add(InsnNode(IXOR))
                il.add(VarInsnNode(ILOAD, 3))
                il.add(InsnNode(IXOR))
                il.add(ldcInt(0xFFFF))
                il.add(InsnNode(IAND))
                il.add(InsnNode(I2C))
                il.add(InsnNode(CASTORE))
            }
            2 -> {
                // layer2 = chars[i]; layer1 = layer2 ^ (classHash+methodHash+i); out = layer1 ^ key[i%8]
                il.add(VarInsnNode(ALOAD, 7))
                il.add(VarInsnNode(ILOAD, 8))
                il.add(VarInsnNode(ALOAD, 5))
                il.add(VarInsnNode(ILOAD, 8))
                il.add(InsnNode(CALOAD))
                il.add(VarInsnNode(ILOAD, 2))
                il.add(VarInsnNode(ILOAD, 3))
                il.add(InsnNode(IADD))
                il.add(VarInsnNode(ILOAD, 8))
                il.add(InsnNode(IADD))
                il.add(InsnNode(IXOR))
                il.add(VarInsnNode(ALOAD, 6))
                il.add(VarInsnNode(ILOAD, 8))
                il.add(ldcInt(8))
                il.add(InsnNode(IREM))
                il.add(InsnNode(IALOAD))
                il.add(InsnNode(IXOR))
                il.add(ldcInt(0xFFFF))
                il.add(InsnNode(IAND))
                il.add(InsnNode(I2C))
                il.add(InsnNode(CASTORE))
            }
            else -> {
                // Default: simple XOR with key
                il.add(VarInsnNode(ALOAD, 7))
                il.add(VarInsnNode(ILOAD, 8))
                il.add(VarInsnNode(ALOAD, 5))
                il.add(VarInsnNode(ILOAD, 8))
                il.add(InsnNode(CALOAD))
                il.add(VarInsnNode(ALOAD, 6))
                il.add(VarInsnNode(ILOAD, 8))
                il.add(ldcInt(8))
                il.add(InsnNode(IREM))
                il.add(InsnNode(IALOAD))
                il.add(InsnNode(IXOR))
                il.add(VarInsnNode(ILOAD, 2))
                il.add(InsnNode(IXOR))
                il.add(ldcInt(0xFFFF))
                il.add(InsnNode(IAND))
                il.add(InsnNode(I2C))
                il.add(InsnNode(CASTORE))
            }
        }

        // i++
        il.add(IincInsnNode(8, 1))
        il.add(JumpInsnNode(GOTO, loopStart))
        il.add(loopEnd)

        // return new String(out)
        il.add(VarInsnNode(ALOAD, 7))
        il.add(MethodInsnNode(INVOKESPECIAL, "java/lang/String", "<init>", "([C)V", false))

        // Actually: new String(out)
        il.add(TypeInsnNode(NEW, "java/lang/String"))
        il.add(InsnNode(DUP))
        il.add(VarInsnNode(ALOAD, 7))
        il.add(MethodInsnNode(INVOKESPECIAL, "java/lang/String", "<init>", "([C)V", false))
        il.add(InsnNode(ARETURN))

        mn.maxLocals = 12
        mn.maxStack = 8
        cn.methods.add(mn)
        return mn
    }

    /** Anti-dump: detect javaagent / debug flags */
    private fun buildAntiDumpMethod(cn: ClassNode): MethodNode {
        val mn = MethodNode(ACC_PRIVATE or ACC_STATIC, "z", "()Z", null, null)
        val il = mn.instructions
        val noAgent = LabelNode()

        // RuntimeMXBean.getInputArguments()
        il.add(MethodInsnNode(
            INVOKESTATIC,
            "java/lang/management/ManagementFactory",
            "getRuntimeMXBean",
            "()Ljava/lang/management/RuntimeMXBean;",
            false
        ))
        il.add(MethodInsnNode(
            INVOKEINTERFACE,
            "java/lang/management/RuntimeMXBean",
            "getInputArguments",
            "()Ljava/util/List;",
            true
        ))
        il.add(MethodInsnNode(INVOKEINTERFACE, "java/util/List", "toString", "()Ljava/lang/String;", true))
        il.add(VarInsnNode(ASTORE, 0))

        // Check "javaagent"
        il.add(VarInsnNode(ALOAD, 0))
        il.add(LdcInsnNode("javaagent"))
        il.add(MethodInsnNode(INVOKEVIRTUAL, "java/lang/String", "contains", "(Ljava/lang/CharSequence;)Z", false))
        il.add(JumpInsnNode(IFEQ, noAgent))
        il.add(InsnNode(ICONST_1))
        il.add(InsnNode(IRETURN))

        il.add(noAgent)
        // Check debug port
        il.add(VarInsnNode(ALOAD, 0))
        il.add(LdcInsnNode("jdwp"))
        il.add(MethodInsnNode(INVOKEVIRTUAL, "java/lang/String", "contains", "(Ljava/lang/CharSequence;)Z", false))
        il.add(JumpInsnNode(IFEQ, LabelNode().also { il.add(it) }))
        il.add(InsnNode(ICONST_1))
        il.add(InsnNode(IRETURN))

        il.add(InsnNode(ICONST_0))
        il.add(InsnNode(IRETURN))
        mn.maxLocals = 2
        mn.maxStack = 3
        cn.methods.add(mn)
        return mn
    }

    /** Generate fake dead method that looks like a decryptor but returns garbage */
    private fun buildFakeMethod(cn: ClassNode, idx: Int) {
        val mn = MethodNode(
            ACC_PRIVATE or ACC_STATIC,
            "f$idx",
            "(Ljava/lang/String;)Ljava/lang/String;",
            null, null
        )
        val il = mn.instructions
        when (idx % 4) {
            0 -> {
                // Returns null
                il.add(InsnNode(ACONST_NULL))
                il.add(InsnNode(ARETURN))
            }
            1 -> {
                // Throws fake exception
                il.add(TypeInsnNode(NEW, "java/lang/RuntimeException"))
                il.add(InsnNode(DUP))
                il.add(LdcInsnNode("internal error"))
                il.add(MethodInsnNode(INVOKESPECIAL, "java/lang/RuntimeException", "<init>", "(Ljava/lang/String;)V", false))
                il.add(InsnNode(ATHROW))
            }
            2 -> {
                // Returns input unchanged (looks real but isn't)
                il.add(VarInsnNode(ALOAD, 0))
                il.add(InsnNode(ARETURN))
            }
            3 -> {
                // Returns empty string
                il.add(LdcInsnNode(""))
                il.add(InsnNode(ARETURN))
            }
        }
        mn.maxLocals = 2
        mn.maxStack = 4
        cn.methods.add(mn)
    }
}
