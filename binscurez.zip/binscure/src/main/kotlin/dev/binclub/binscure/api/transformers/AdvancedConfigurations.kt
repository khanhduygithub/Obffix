package dev.binclub.binscure.api.transformers

import dev.binclub.binscure.api.TransformerConfiguration

/**
 * Configuration for Anti-Tamper injection (CRC + debugger detection)
 */
data class AntiTamperConfiguration(
    override val enabled: Boolean = false,
    val crcCheck: Boolean = true,
    val debuggerDetect: Boolean = true,
    val agentDetect: Boolean = true,
    private val exclusions: List<String> = arrayListOf()
) : TransformerConfiguration(enabled, exclusions)

/**
 * Configuration for Dead Code injection
 */
data class DeadCodeConfiguration(
    override val enabled: Boolean = false,
    // 1 = inject in every eligible spot, 10 = inject in ~1/10 spots
    val density: Int = 5,
    private val exclusions: List<String> = arrayListOf()
) : TransformerConfiguration(enabled, exclusions)

/**
 * Configuration for Unicode rename obfuscation
 */
data class UnicodeRenameConfiguration(
    override val enabled: Boolean = false,
    val useKeywords: Boolean = true,
    val useUnicode: Boolean = true,
    private val exclusions: List<String> = arrayListOf()
) : TransformerConfiguration(enabled, exclusions)
